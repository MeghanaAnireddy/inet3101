#include<stdio.h>
#include<string.h>
#include<stdbool.h>

int PrintNumChanges (bool print){
    static int changes = 0;

    if (print){
        printf("Database has been modified %d time\n", changes);
    }else{
        changes++;
        printf("%d modificiations so far\n", changes);
    }
    return changes;
    }


int main()
{
    int ch,pnumber;
    float psize, pcost;
    // both char values are initialized as empty strings
    char pname[50] = "";
    char psize_metric[10] = "";

    while(1){

    printf("\n MENU");
    printf("\n 1. Print all records");
    printf("\n 2. Add record");
    printf("\n 3. Delete record");
    printf("\n 4. Print number of records");
    printf("\n 5. Print database size");
    printf("\n 6. Print Number of Changes");
    printf("\n 7. Exit");
    printf("\n Please enter you selection numerically: ");
    scanf("%d", &ch);
    getchar();

    switch(ch)
    {
        case 1:
        printf("You have entered the Print all records function\n");
        break;

        case 2:
        printf("Enter part number: ");
        scanf("%d", &pnumber);
        getchar();
        
        printf("Enter part name: ");
        fgets(pname, sizeof(pname), stdin);
        pname[strcspn(pname, "\n")] = 0; //removes newline

        printf("Enter part size: ");
        scanf("%f", &psize);
        getchar();
       
       printf("Enter part size metric: ");
       fgets (psize_metric, sizeof(psize_metric), stdin);
       psize_metric[strcspn(psize_metric, "\n")]=0;
        
        printf("Enter part cost: ");
        scanf("%f", &pcost);
        getchar();

        //To ensure the output prints correctly without the buffer
        fflush(stdout);

        printf("\nYou entered");
        printf("\n Part number: %d", pnumber);
        printf("\n Part name: \"%s\"", pname);
        printf("\n Part size: %.2f", psize);
        printf("\n Part Size Metric: \"%s\"", psize_metric);
        printf("\n Part cost: %.2f\n", pcost);

        break;
    
    case 3:
    printf("You have entered the delete last record function\n");
    break;

    case 4:
    printf("You have entered the Print number of records function\n");
    break;

    case 5:
    printf("You have entered the Print database size function\n");
    break;

    //Uses the bool value initialized at the beginning fo the code
    case 6:
    PrintNumChanges(true);
    break;

    case 7:
    printf("Exiting the program\n");
    return 0;

    default: 
    printf("Invalid section. Please try again.\n");
    break;

    }
    }
    return 0;
}